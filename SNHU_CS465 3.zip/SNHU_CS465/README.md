# Travlr Getaways - Full Stack Application

Travlr Getaways is a full-stack web application designed to help users explore and book travel trips. The application includes a backend built with **Node.js**, **Express**, and **MongoDB**, and a frontend built with **Angular**.

---

## Features
- **User Authentication**: Register and log in to access trip management features.
- **Trip Management**: Add, edit, and view trips.
- **Dynamic Trip Listings**: Display trips with images, descriptions, and pricing.
- **RESTful API**: Backend API for managing trips and user authentication.

---

## Technologies Used
- **Backend**:
  - Node.js
  - Express
  - MongoDB (with Mongoose)
  - JSON Web Tokens (JWT) for authentication
- **Frontend**:
  - Angular
  - Bootstrap for styling
- **Tools**:
  - Postman (for API testing)
  - MongoDB Compass (for database management)

---

## Setup Instructions

### Prerequisites
- **Node.js** (v18 or higher)
- **MongoDB** (running locally or via a cloud service)
- **Angular CLI** (for frontend development)

